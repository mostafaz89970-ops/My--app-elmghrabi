
import React, { useState, useEffect, useMemo } from 'react';
import Login from './components/Login';
import DashboardLayout from './components/DashboardLayout';
import LightingRegistration from './pages/LightingRegistration';
import RegistrationList from './pages/RegistrationList';
import Settings from './pages/Settings';
import DashboardHome from './pages/DashboardHome';
import Reports from './pages/Reports';
import AddUser from './pages/AddUser';
import Permissions from './pages/Permissions';
import UserActivityPage from './pages/UserActivityPage';
import { Transformer, LightingRecord, User, Notification, UserActivity, UserRole } from './types';
import { INITIAL_USERS } from './constants';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [transformers, setTransformers] = useState<Transformer[]>([]);
  const [records, setRecords] = useState<LightingRecord[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [activities, setActivities] = useState<UserActivity[]>([]);
  const [currentPage, setCurrentPage] = useState<string>('home');

  useEffect(() => {
    const savedUsers = localStorage.getItem('app_users');
    if (savedUsers) setUsers(JSON.parse(savedUsers));
    else setUsers(INITIAL_USERS);

    const savedTransformers = localStorage.getItem('transformers');
    if (savedTransformers) setTransformers(JSON.parse(savedTransformers));

    const savedRecords = localStorage.getItem('records');
    if (savedRecords) {
      const parsed = JSON.parse(savedRecords);
      setRecords(sortRecords(parsed));
    }

    const savedActivities = localStorage.getItem('user_activities');
    if (savedActivities) setActivities(JSON.parse(savedActivities));
  }, []);

  const sortRecords = (recs: LightingRecord[]) => {
    return [...recs].sort((a, b) => b.timestamp - a.timestamp);
  };

  const logActivity = (action: string, details: string) => {
    if (!user) return;
    const newActivity: UserActivity = {
      id: Date.now().toString(),
      userId: user.id,
      username: user.username,
      action,
      details,
      timestamp: Date.now()
    };
    const updated = [newActivity, ...activities];
    setActivities(updated);
    localStorage.setItem('user_activities', JSON.stringify(updated));
  };

  const handleAddTransformer = (name: string, chassisNumber: string) => {
    const newTransformer = { id: Date.now().toString() + Math.random(), name, chassisNumber };
    const updated = [...transformers, newTransformer];
    setTransformers(updated);
    localStorage.setItem('transformers', JSON.stringify(updated));
    logActivity('إضافة محول', `إضافة محول جديد باسم: ${name}`);
  };

  const handleUpdateTransformer = (id: string, name: string, chassisNumber: string) => {
    const updated = transformers.map(t => t.id === id ? { ...t, name, chassisNumber } : t);
    setTransformers(updated);
    localStorage.setItem('transformers', JSON.stringify(updated));
    
    const updatedRecords = records.map(r => r.transformerId === id ? { ...r, transformerName: name, chassisNumber } : r);
    setRecords(updatedRecords);
    localStorage.setItem('records', JSON.stringify(updatedRecords));
  };

  const handleDeleteTransformer = (id: string) => {
    const t = transformers.find(x => x.id === id);
    const updated = transformers.filter(t => t.id !== id);
    setTransformers(updated);
    localStorage.setItem('transformers', JSON.stringify(updated));
    logActivity('حذف محول', `حذف المحول: ${t?.name}`);
  };

  const handleUpdateRecord = (id: string, updatedData: Partial<LightingRecord>) => {
    const updated = records.map(r => r.id === id ? { ...r, ...updatedData } : r);
    const sorted = sortRecords(updated);
    setRecords(sorted);
    localStorage.setItem('records', JSON.stringify(sorted));
  };

  const handleAddRecord = (record: Omit<LightingRecord, 'id'>) => {
    const newRecord: LightingRecord = {
      ...record,
      id: Date.now().toString() + Math.random(),
    };
    const updated = sortRecords([newRecord, ...records]);
    setRecords(updated);
    localStorage.setItem('records', JSON.stringify(updated));
    logActivity('تسجيل إنارة', `تسجيل قراءة لمحول: ${record.transformerName} عن فترة ${record.date}`);
    setCurrentPage('record-list');
  };

  const handleDeleteMonth = (month: number, year: number) => {
    const monthNames = [
      'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
      'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
    ];
    
    const updated = records.filter(r => {
      const d = new Date(r.timestamp);
      return !(d.getMonth() === month && d.getFullYear() === year);
    });
    
    setRecords(updated);
    localStorage.setItem('records', JSON.stringify(updated));
    logActivity('حذف شهر', `تم حذف كافة سجلات شهر ${monthNames[month]} لعام ${year}`);
    alert(`تم حذف سجلات شهر ${monthNames[month]} بنجاح`);
  };

  const handleBulkImport = (
    newTransformers: Transformer[], 
    importedRecords: LightingRecord[], 
    stats: { totalRowsFound: number }
  ) => {
    if (importedRecords.length === 0) {
      alert(`لم يتم العثور على أي بيانات صالحة للاستيراد في الملف.`);
      return;
    }

    let updatedTransformers = [...transformers];
    let newAddedCount = 0;
    
    newTransformers.forEach(nt => {
      const normalize = (t: string) => t.trim().replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/\s+/g, '').toLowerCase();
      const exists = updatedTransformers.find(t => normalize(t.name) === normalize(nt.name));
      
      if (!exists) {
        updatedTransformers.push(nt);
        newAddedCount++;
      } else {
        if (nt.chassisNumber && nt.chassisNumber !== '---' && nt.chassisNumber !== exists.chassisNumber) {
          exists.chassisNumber = nt.chassisNumber;
        }
      }
    });

    setTransformers([...updatedTransformers]);
    localStorage.setItem('transformers', JSON.stringify(updatedTransformers));

    const finalRecords = [...records];
    let addedRecCount = 0;
    let updatedRecCount = 0;

    importedRecords.forEach(newRec => {
      const d = new Date(newRec.timestamp);
      const m = d.getMonth();
      const y = d.getFullYear();

      const existingIdx = finalRecords.findIndex(r => {
        const rd = new Date(r.timestamp);
        return r.transformerId === newRec.transformerId && rd.getMonth() === m && rd.getFullYear() === y;
      });

      if (existingIdx !== -1) {
        finalRecords[existingIdx] = { 
          ...finalRecords[existingIdx], 
          previousReading: newRec.previousReading,
          currentReading: newRec.currentReading,
          difference: newRec.difference,
          notes: newRec.notes || finalRecords[existingIdx].notes,
          chassisNumber: newRec.chassisNumber
        };
        updatedRecCount++;
      } else {
        finalRecords.push(newRec);
        addedRecCount++;
      }
    });

    const sorted = sortRecords(finalRecords);
    setRecords(sorted);
    localStorage.setItem('records', JSON.stringify(sorted));
    
    const msg = `تمت معالجة ملف الإكسل بنجاح.`;
    alert(msg);
    logActivity('استيراد شامل', `استيراد بيانات من إكسل لعدد ${stats.totalRowsFound} صف.`);
    setCurrentPage('record-list');
  };

  const handleAddUser = (username: string, role: UserRole, password: string) => {
    const newUser: User = {
      id: Date.now().toString(),
      username,
      password,
      role,
      permissions: {
        canAddRecord: true,
        canEditRecord: role === 'admin',
        canManageTransformers: role === 'admin',
        canViewReports: true,
        canManageUsers: role === 'admin'
      }
    };
    const updated = [...users, newUser];
    setUsers(updated);
    localStorage.setItem('app_users', JSON.stringify(updated));
    logActivity('إضافة مستخدم', `إضافة مستخدم جديد: ${username}`);
  };

  const handleUpdatePermissions = (userId: string, permissions: User['permissions']) => {
    const updated = users.map(u => u.id === userId ? { ...u, permissions } : u);
    setUsers(updated);
    localStorage.setItem('app_users', JSON.stringify(updated));
  };

  if (!user) {
    return <Login onLogin={setUser} users={users} />;
  }

  const isAdmin = user.role === 'admin';

  const renderContent = () => {
    switch (currentPage) {
      case 'home': return <DashboardHome records={records} transformers={transformers} onNavigate={setCurrentPage} />;
      case 'register-lighting': return <LightingRegistration transformers={transformers} records={records} onSave={handleAddRecord} />;
      case 'record-list': return <RegistrationList records={records} onUpdateRecord={handleUpdateRecord} onDeleteMonth={handleDeleteMonth} canDeleteMonth={isAdmin} />;
      case 'settings-transformers': return <Settings transformers={transformers} isAdmin={isAdmin} onAdd={handleAddTransformer} onUpdate={handleUpdateTransformer} onDelete={handleDeleteTransformer} onImport={handleBulkImport} />;
      case 'reports': return <Reports records={records} transformers={transformers} />;
      case 'add-user': return <AddUser onAdd={handleAddUser} />;
      case 'permissions': return <Permissions users={users} onUpdate={handleUpdatePermissions} />;
      case 'user-activity': return <UserActivityPage activities={activities} onReset={() => setActivities([])} isAdmin={isAdmin} />;
      default: return <DashboardHome records={records} transformers={transformers} onNavigate={setCurrentPage} />;
    }
  };

  return (
    <DashboardLayout user={user} notifications={notifications} onLogout={() => setUser(null)} onNavigate={setCurrentPage} onMarkRead={(id) => setNotifications(prev => prev.map(n => n.id === id ? {...n, isRead: true} : n))} activePage={currentPage}>
      {renderContent()}
    </DashboardLayout>
  );
};

export default App;
